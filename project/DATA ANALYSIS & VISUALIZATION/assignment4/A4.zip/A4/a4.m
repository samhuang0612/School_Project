%%Student name: Lishan Huang
%%Student number: 250777962
%% Coding part
%{
 *create D1 to read the London_South_Monthly_1883-1932.csv
  and store the data from line 19
 *create D2 to read the London_Lambeth_A_Monthly_1930-1941.csv
  and store the data from line 19
*create D2 to read the London_Intl_Airport_Monthly_1940-2006.csv
  and store the data from line 19
%}
D1 = csvread('London_South_Monthly_1883-1932.csv',19,1);
D2 = csvread('London_Lambeth_A_Monthly_1930-1941.csv',19,1);
D3 = csvread('London_Intl_Airport_Monthly_1940-2006.csv',19,1);
D = [D1(3:end-8,:); D2(29:end-17,:); D3(8:end-50,:)];
%create matrix ylabels to store the data type of each line
ylabels = {'Year','Month','Mean Max Temp (�C)','Mean Min Temp (�C)',...
    'Mean Temp (�C)','Extr Max Temp (�C)','Extr Min Temp (�C)',...
    'Total Rain (mm)','Total Snow (cm)','Total Precip (mm)'};
%create matrix titles to store the data type of each line
titles = {'Year','Month','Mean Maximum Temperature (�C)',...
    'Mean Minimum Temperature (�C)','Mean Temperature (�C)',...
    'Extreme Maximum Temp (�C)','Extreme Minimum Temp (�C)',...
    'Total Rain (mm)','Total Snow (cm)','Total Precipitation (mm)'};
% for loop from 3 to 8 print
for i=3:10
    figure
    %store the year and the month into x
    x=D(:,1)+((D(:,2)-1)/12 );
    %plot x and the ith data
    plot(x,D(:,i))
    xlabel('Year')%label x axis
    ylabel(ylabels(i))%label y axis
    title(strcat('London Ontario'," ", titles(i)))%set title with data type
    axis tight
    set(gcf,'Position',[100 100 800 400])%set the value x and y axis
    titlevalue=(strcat(titles(i),'.png'));%set the  filename
    m=char(titlevalue);%cast the name to charater
    print('-dpng',m)
   
end
%the first for loop loop each seasion
% for a from 1 to 3 are spring
% for a from 4 to 7 are summer
% for a from 8 to 10 are autumn
% for a from 11 to 1 are autumn
for(a=1:3:10)
    %second for loop loop each type of data
    % if c =1 then the data type is the 3rd line in D which is Mean Maximum Temperature
    % if c =2 then the data type is the 6th line in D which is Extreme Maximum Temperature
    % if c =3 then the data type is the 7th line in D which is Extreme Minimum Temperature
    % if c =4 then the data type is the 8th line in D which is Total Rain
    for(c=1:4)
        %get the number of year;
        n_years = floor(size(D,1)/12);
        if(a==1)
            %if the remainder larger than 3 then there are one more spring
            if (rem(size(D,1),12) >= 3)
                n_years = n_years+1;
            end
        elseif(a==4)
            %if the remainder larger than 5 then there are one more summer
            if (rem(size(D,1),12) >= 6)
                n_years = n_years+1;
            end
        elseif(a==7)
            %if the remainder larger than 8 then there are one more autumn
            if (rem(size(D,1),12) >= 9)
                n_years = n_years+1;
            end
        end
        %put the first year into container years
        years = D(1,1);
        if(c==1)
            % if data type is Mean Maximum Temperature
            % sum up all the temperature and devide it
            if(a==1)
                data = (D(a,3)*31 + D(a+1,3)*30 + D(a+2,3)*31)/(31+30+31);
            elseif(a==4)
                data = (D(a,3)*30 + D(a+1,3)*31 + D(a+2,3)*31)/(31+30+31);
            elseif(a==7)
                data =  (D(a,3)*30 + D(a+1,3)*31 + D(a+2,3)*30)/(31+30+30);
            elseif(a==10)
                %if it is leap year which can be division by 4 then the
                %day of February is 29 otherwise is 28
                if(rem(D(first_element,1),4)==0)
                    data =  (D(a,3)*31 + D(a+1,3)*31 + D(a+2,3)*29)/(31+29+31);
                else
                    data =  (D(a,3)*31 + D(a+1,3)*31 + D(a+2,3)*28)/(31+28+31);
                end
            end
        elseif(c==2)
            %if data type is Extreme Maximum Temp
            %then data store maximum Temperature in those three month
            data = max(D(a:a+2,6));
        elseif(c==3)
            %if data type is Extreme Minimum Temp
            %then data store the minimum Temperature in those three month
            data = min(D(a:a+2,7));
        elseif(c==4)
            %if data type is Total Rain
            %then data store the total precipitation amounts in those three month
            data = sum(D(a:a+2,8));
        end
        %because the first one already store in years and data
        %then should store the information from the second one
        for i=1:n_years-1
            %get the first month and the last month in each season
            first_element = a+i*12;
            last_element = a+2+i*12;
            if(c==1)%in the first type store the information in 3rd line
                yrdata = D(first_element:last_element,3);
            elseif(c==2)%in the second type store the information in 6th line
                yrdata = D(first_element:last_element,6);
            elseif(c==3)%in the third type store the information in 7th line
                yrdata = D(first_element:last_element,7);
            elseif(c==4)%in the forth type store the information in 8th line
                yrdata = D(first_element:last_element,8);
            end
            if (~any(isnan(yrdata)))%if the information is not NaN then store it into data
                years(end+1,1) = D(first_element,1);
                if(c==1)  % if data type is Mean Maximum Temperature sum up all the temperature and devide it
                    if(a==1)%same as above loop
                        data(end+1,1) = (yrdata(1)*31 + yrdata(2)*30 + yrdata(3)*31)/(31+30+31);
                    elseif(a==4)
                        data(end+1,1) = (yrdata(1)*30 + yrdata(2)*31 + yrdata(3)*31)/(31+30+31);
                    elseif(a==7)
                        data(end+1,1) = (yrdata(1)*30 + yrdata(2)*31 + yrdata(3)*31)/(31+31+30);
                    elseif(a==10)
                        if(rem(D(first_element,1),4)==0)
                            data(end+1,1) = (yrdata(1)*31 + yrdata(2)*31 + yrdata(3)*31)/(31+31+29);
                        else
                            data(end+1,1) = (yrdata(1)*31 + yrdata(2)*31 + yrdata(3)*31)/(31+31+28);
                        end
                    end
                elseif(c==2)% same as above loop
                    data(end+1,1) = max(yrdata) ;
                elseif(c==3)
                    data(end+1,1) = min(yrdata);
                elseif(c==4)
                    data(end+1,1) = sum(yrdata);
                end
            end
        end
        %get the regress function
        [b, bint] = regress(data,[ones(length(years),1),years],0.32);
        if(a==1)%a==1 which months are spring
            name='Spring';
        elseif(a==4)%a==4 which months are summer
            name='Summer';
        elseif(a==7)%a==4 which months are sautumn
            name='Autumn';
        else        %else are winter
            name='Winter';
        end
        % titles(n) and ylabels(n) will be set based on the data type
        if(c==1) %c=1 means the data type is the thrid line infromation
            n=3; % then read Mean Maximum Temperature
        elseif(c==2)%same as above
            n=6;
        elseif(c==3)
            n=7;
        else
            n=8;
        end
        figure
        plot(years,data) %plot the axis
        axis tight
        hold on
        xlabel('Year')%label axis
        ylabel(ylabels(n))
        title(strcat('London Ontario '," ", name, " ", titles(n)))%label title
        plot(years,b(2)*years+b(1),'LineWidth',2)
        hold off
        %bint is the inverval of the slope and bint(2,1) is the left and
        %bint (2,2) is right bound
        left_conf_bound=bint(2,1);%set left confidence bounds
        right_conf_bound=bint(2,2);%set right confidence bounds
        slope=b(2);%set the slope
        if (slope>0)%display accounding to the slope
            disp(strcat('Potential increasing trend for'," ",titles(n)," in ",name,' :'))
        elseif (slope<0)
            disp(strcat('Potential decreasing trend for'," ",titles(n)," in ",name,' :'))
        end
        if (sign(left_conf_bound) == sign(right_conf_bound))
            disp(' Significant trend at 68% confidence!')
            sigma = abs(slope-left_conf_bound);%set sigma
            fprintf(' Trend is %f +/- %f ',b(2)*100,sigma*100);
            if(c==1 || c==2)%add the unit based on the data type
                fprintf('�C/century\n');
            elseif(c==3)
                fprintf('mm/century\n');
            elseif (c==4)
                fprintf('cm/century\n');
            end%move the inverval with one sigma if still in intersect then it is 95% confidenc
            if (sign(left_conf_bound-sigma) == sign(right_conf_bound+sigma))
                disp(' Significant trend at 95% confidence too!')
            end
        else
            disp(' Trend is not statistically significant')
        end
        disp(' ')
    end
end
%% Discussion of Results

%%Spring:
%decreasing trend for Mean Maximum Temperature (�C)
%decreasing trend for Extreme Maximum Temp
      %Significant trend at 68% confidence!
%increasing trend for Extreme Minimum Temp (�C)
      %Significant trend at 68% confidence!
      %Significant trend at 95% confidence too!
%increasing trend for Total Rain (mm)
      % Significant trend at 68% confidence!
      
      
%%Summer:
%decreasing trend for Mean Maximum Temperature (�C)
      %Significant trend at 68% confidence!
      %Significant trend at 95% confidence too!
%decreasing trend for Extreme Maximum Temp (�C)
      %Significant trend at 68% confidence!
      %Significant trend at 95% confidence too!
%increasing trend for Extreme Minimum Temp
      %Significant trend at 68% confidence!
      %Significant trend at 95% confidence too!
%increasing trend for Total Rain (mm)


%%Autumn
%decreasing trend for Mean Maximum Temperature (�C)
      % Significant trend at 68% confidence!
%decreasing trend for Extreme Maximum Temp (�C)
      %Significant trend at 68% confidence!
      %Significant trend at 95% confidence too!
%increasing trend for Extreme Minimum Temp (�C)
      %Significant trend at 68% confidence!
%increasing trend for Total Rain (mm)
      %Significant trend at 68% confidence!
      %Significant trend at 95% confidence too!

      
%%Winter
%increasing trend for Mean Maximum Temperature (�C)
%increasing trend for Extreme Maximum Temp (�C)
     %Significant trend at 68% confidence!
%increasing trend for Extreme Minimum Temp (�C)
     %Significant trend at 68% confidence!
     %Significant trend at 95% confidence too!
%decreasing trend for Total Rain (mm)
     
%%assessment:
% In winter and spring the extre maximum temperature were increasing
% in past 100 years, but the extre maximum temperature were decreasing
% in summer and autumn. The Extreme Minimum temperature were increasing
% in past 100 years, and the total railfall was changed significantly
% Thus what we can predict is the extreme minimum temperature will be
% increasing in the future.
